﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathMenu : MonoBehaviour {

    Player player;
	public string mainMenuLevel;

    void Update(){

        

    }
	

    public void RestartGame()
    {

        FindObjectOfType<GameManager>().Reset();

    }

    public void QuitToMainMenu()
    {

		Application.LoadLevel(mainMenuLevel);
    }

    public void DestroyObjects(string tag){
        GameObject[] gameObjects = GameObject.FindGameObjectsWithTag(tag);
        foreach(GameObject target in gameObjects){
            GameObject.Destroy(target);
        }
    }
}
