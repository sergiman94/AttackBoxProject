﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
public GameManager theGameManager;
public Transform upCheck;

public bool up;

public int damage = 100;

public DeathMenu deathMenu;


    [System.Serializable]
    public static class PlayerStats
    {

        public static int maxHealth = 100;
		

        private static int _curHealth;
        public static  int curHealth
        {
            get { return _curHealth; }
            set { _curHealth = Mathf.Clamp(value, 0, maxHealth); }
        }

        public static void init(){
            
            curHealth = maxHealth;
        
        }
    
    }

    //PlayerStats playerStats = new PlayerStats();

    [SerializeField]
    private StatusIndicator statusIndicator;

    void Start()
    {
        PlayerStats.init();

        if (statusIndicator == null){

            Debug.LogError("No StatusIndicator referenced on player! ");

        }else{

            statusIndicator.SetHealth(PlayerStats.curHealth, PlayerStats.maxHealth);
        }

    }


    void Update()
    {

        // if(Player.PlayerStats.curHealth <= 0){
        //     theGameManager.RestartGame();
        // }

    }

	void FixedUpdate(){
		up = IsUp();

		if (up){
			// Debug.Log("Hitted");

			DamagePlayer(damage);
            //theGameManager.RestartGame();
		}
	}


	public bool IsUp(){

        float upDist = GetComponent<Collider>().bounds.extents.y + 0.5f;

        RaycastHit upHit;
        Vector3 upDir = upCheck.TransformDirection(Vector3.up * upDist);

        Ray upRay = new Ray(upCheck.position, upDir);

        Debug.DrawRay(upCheck.position, upDir, Color.green);

        if (Physics.Raycast(upRay, out upHit, upDist))
        {

            return true;

        }else{

            return false;
        }

    }

	public void DamagePlayer(int damageAmount){
        

        PlayerStats.curHealth -= damageAmount;


        if (PlayerStats.curHealth <= 0) {

            
            theGameManager.KillPlayer(this);
            theGameManager.RestartGame();

            deathMenu.gameObject.SetActive(true);

        }

        statusIndicator.SetHealth(PlayerStats.curHealth, PlayerStats.maxHealth);

    }
}
