﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxInstantiate : MonoBehaviour {


    //public GameObject prefab;
    public float firstFrameWaitTime;
    private float InstantiationTimer;

    public List<GameObject> prefabList = new List<GameObject>();

    private bool invokePrefab;
    private int prefabIndex;

    private float ps;

    Positions positions;

    // Use this for initialization
    void Start()
    {
        StartCoroutine(WaitFirstFrameCreatePrefab(firstFrameWaitTime));

        positions = GetComponent<Positions>();

        
        
    }

    // Update is called once per frame
    void Update()
    {   
        // toma una caja al azar  
        prefabIndex = UnityEngine.Random.Range(0, prefabList.Count);

        CreatePrefab();

        ps = UnityEngine.Random.Range(0, 5);
    }

    void CreatePrefab()
    {

        Vector3 newPos = new Vector3(transform.position.x + ps, transform.position.y, transform.position.z);

        //float posX = UnityEngine.Random.Range(0, positions.arregloDePositions.Length);
        //Vector3 newPos = new Vector3(posX, transform.position.y, transform.position.z);


        InstantiationTimer -= Time.deltaTime;

        if (invokePrefab)
        {

            if (InstantiationTimer <= 0)
            {

                //Instantiate(prefab, transform.position, Quaternion.identity);
                Instantiate(prefabList[prefabIndex], newPos, Quaternion.identity);
                InstantiationTimer = 5f;
            }

        }
        else
        {
            return;
        }


    }

    IEnumerator WaitFirstFrameCreatePrefab(float waitTime)
    {

        invokePrefab = false;

        yield return new WaitForSeconds(waitTime);

        invokePrefab = true;


    }

}
