﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cubes : MonoBehaviour {

	//(1)
    public GameObject[,] cubeMatrix2;
    public Transform[,] cubeMatrix2Transform;
    public int numCube = 8; //30x30=900 //public se objeví v Extending Editoru!
    int ii = 0;
    public Renderer rend2;
    public Vector3 startMatrix; //stred vykresleni matice

    private BoxCollider cubeCollider;
    private Vector3  bounds;
    private float xBound;


    //==================================================================================
    void Start () {
        Debug.Log("---> oe900cubes.start() > TestCreateMatrix2");

		//donde aparece la matriz al inicio de le escena
        startMatrix = new Vector3(-14.64f, 0, 0);  //pocatek vykresleni matice
        TestCreateMatrix2();
    }

	void Update () {
    }
    //==================================================================================
    private void TestCreateMatrix2()
    {
        cubeMatrix2 = new GameObject[numCube , numCube];
        cubeMatrix2Transform = new Transform[numCube,numCube];
        MatrixGrid.grid = cubeMatrix2Transform;
        

        // matriz roja (primera fila)- imán 
        for (int i = 0; i < numCube-1; i++)
        {
            for (int j = 0; j < 1; j++)
            {
                Debug.Log("i-> "+i.ToString()+" j->" + j.ToString());

                
				
				cubeMatrix2[i, j] = GameObject.CreatePrimitive(PrimitiveType.Cube);

                cubeCollider = cubeMatrix2[i,j].GetComponent<BoxCollider>();
                cubeCollider.enabled = true;
                cubeCollider.isTrigger = true;

                bounds = cubeCollider.bounds.size;
                xBound = bounds.x;

				cubeMatrix2[i, j].transform.localScale = new Vector3(1.8f, 1.8F, 1.8F);
				cubeMatrix2[i, j].transform.position = new Vector3(startMatrix.x + i, startMatrix.y + j + 1.1f, startMatrix.z 	);
                

                cubeMatrix2[i,j].AddComponent<Rigidbody>();
                cubeMatrix2[i,j].GetComponent<Rigidbody>().useGravity = false;

                cubeMatrix2[i,j].AddComponent<MagnetActions>();

                rend2 = cubeMatrix2[i, j].GetComponent<Renderer>();
                rend2.material.color = Color.red;

                

                cubeMatrix2[i,j].gameObject.tag = "Magnet";

                
            }
        }

        

        
        // // Matriz azul (despues de la segunda fila)
        // for (int i = 0 ; i   < numCube; i++)
        // {
        //     for (int j =2 ; j < numCube - 15; j++)
        //     {
        //         Debug.Log("i-> "+i.ToString()+" j->" + j.ToString());

			
        //         //cubeMatrix2[i ,j] = (GameObject)Instantiate(GameObject.CreatePrimitive(PrimitiveType.Cube),  new Vector3(startMatrix.x + i, startMatrix.y, startMatrix.z+j), Quaternion.identity);

		// 		cubeMatrix2[i, j] = GameObject.CreatePrimitive(PrimitiveType.Cube);
		// 		//cubeMatrix2[i, j].transform.localScale = new Vector3(0.95F, 1F, 0.95F);
		// 		cubeMatrix2[i, j].transform.localScale = new Vector3(1.8f, 1.8F, 1.8F);
		// 		cubeMatrix2[i, j].transform.localPosition = new Vector3(startMatrix.x + i, startMatrix.y + j + 1.1f, startMatrix.z 	);
        //         cubeMatrix2[i,j].GetComponent<Collider>().enabled = false;
				

        //         rend2 = cubeMatrix2[i, j].GetComponent<Renderer>();
        //         //float deltaRnd2 = Mathf.Floor(Random.Range(0, 20));
        //         //if (deltaRnd2 == 1) rend2.material.color = Color.gray;
        //         //if (deltaRnd2 == 2) rend2.material.color = Color.white;
        //         //if (deltaRnd2 > 2) rend2.material.color = Color.black;
        //         rend2.material.color = Color.blue;
        //     }
        // }
    }

    

   

}
