﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MagnetAttraction : MonoBehaviour {
	[HideInInspector]
	public Vector3 newPosition;

	private Vector3 otherPosition;

	[HideInInspector]
	public Transform trans;

	private Rigidbody rb;
	private Renderer renderer;

	private int thisCount;

	private ScoreManager scoreManager;




	void Awake(){
		trans = transform;
		

		rb = GetComponent<Rigidbody>();
		renderer = GetComponent<Renderer>();
		scoreManager = FindObjectOfType<ScoreManager>();
	}

	bool lerp = false;
	void Update(){

		Lerp();

		// if(this.renderer.material.color == Color.green){
		// 	thisCount = 4;
		// }
	}

	void OnTriggerEnter(Collider other){

		otherPosition = other.transform.position;

		if (other.tag == "Magnet"){

			lerp = true;

			// if(Mathf.Abs(newPosition.x - trans.position.x ) < 0.05){
			// 	trans.position = newPosition;
			// }

			if(Mathf.Abs(otherPosition.x - trans.position.x ) < 0.05){
				trans.position = otherPosition;
			}

			rb.isKinematic = true;

			renderer.material.color = Color.green;

			
			StartCoroutine(DestroyObject(1f));

		}else{
			lerp = false;
		}
	}

	void Lerp(){
		if (lerp == true)
			trans.position = Vector3.Lerp(trans.position, otherPosition, Time.deltaTime * 1.5f);
	}

	IEnumerator DestroyObject(float time){

		yield return new WaitForSeconds( time);

		Destroy(this.gameObject);

	}

	

}
