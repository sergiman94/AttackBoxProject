﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour {

	public Text CountText;
    public Text winText;

    public int count;

    void Start(){
        count = 0;
        SetCountText();
        winText.text = "";
    }

    void Update(){

       SetCountText();

    }

    void OnTriggerEnter(Collider other){
        if(other.gameObject.CompareTag ("Magnet")){
            
            count = count +1;
            
            SetCountText();
        }
    }

    void SetCountText(){

        CountText.text = count.ToString();

        //  if(count >= 20)
        //     winText.text = "You Win !";
    }
	
}
