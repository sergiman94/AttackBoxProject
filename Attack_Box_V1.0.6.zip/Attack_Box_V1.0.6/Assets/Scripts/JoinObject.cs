﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JoinObject : MonoBehaviour
{

    private Rigidbody rb;
    [HideInInspector]
    //public FixedJoint joint;
    ConfigurableJoint joint;
    private RigidbodyInterpolation objectDefInterpolation;

    [HideInInspector]
    public GameObject otherObject;

    public Component[] components;

    [HideInInspector]
    public float otherObjectLong;



    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        components = new Component[components.Length];
    }

    // Update is called once per frame
    void Update()
    {
        // if (otherObject && otherObject.tag == "Pickup")
        // {
        //     if (!joint)
        //     {
        //         DisjointObject();
        //     }
        // }

        if (joint)
        {
            //Debug.Log("JOINT");

        }

        

        // Retornamos el joint tiene este objeto y lo ponemos en el arreglo 
        GetJoints();


    }

    //  private void OnTriggerEnter(Collider other)
    // {
    // 	// if( other.tag == "Pickup" && otherObject == null){
    // 	// 	joinObject(other);
    // 	// }

    // }

    void OnCollisionStay(Collision collision){

    }

    public void joinObject(Collider other)
    {
        otherObject = other.gameObject;
        objectDefInterpolation = otherObject.GetComponent<Rigidbody>().interpolation;
        otherObject.GetComponent<Rigidbody>().interpolation = RigidbodyInterpolation.Interpolate;
        Addjoint();

        joint.breakForce = Mathf.Infinity;
        joint.breakTorque = Mathf.Infinity;

        // Cuando se agrega un joint cambiamos de color el objeto
        this.gameObject.GetComponent<Renderer>().material.color = Color.green;

        otherObjectLong = otherObject.gameObject.transform.localScale.x;
        

    }

    public void DisjointObject()
    {

        otherObject.GetComponent<Rigidbody>().interpolation = objectDefInterpolation;
        Destroy(joint);
        otherObject = null;

    }

    void Addjoint()
    {
        if (otherObject)
        {
            //joint = otherObject.AddComponent<FixedJoint>();
            joint = otherObject.AddComponent<ConfigurableJoint>();
            joint.connectedBody = GetComponent<Rigidbody>();
            joint.enableCollision = true;
            joint.configuredInWorldSpace = true;
            joint.xMotion = ConfigurableJointMotion.Locked;
            joint.zMotion = ConfigurableJointMotion.Locked;
            joint.angularZMotion = ConfigurableJointMotion.Locked;
            joint.angularYMotion = ConfigurableJointMotion.Locked;
            
        }

    }

    public float GetJoints(){

        components = this.gameObject.GetComponents(typeof(ConfigurableJoint));

        return components.Length;
    }

    

}
