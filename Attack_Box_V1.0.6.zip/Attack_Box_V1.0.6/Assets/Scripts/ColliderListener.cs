﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColliderListener : MonoBehaviour {

	 

	 void Update()
     {
         // Check if Colider is in another GameObject
         //Collider collider = GetComponentInChildren<Collider>();
		 Collider collider = GameObject.FindGameObjectWithTag("Checks").GetComponent<BoxCollider>();
         if (collider.gameObject != gameObject)
         {
             ColliderBridge cb = collider.gameObject.AddComponent<ColliderBridge>();
             cb.Initialize(this);
         }
     }
     public void OnCollisionEnter(Collision collision)
     {
         // Do your stuff here

		 
     }
     public void OnTriggerEnter(Collider other)
     {
         // Do your stuff here

		 if (other.gameObject.tag == "Pickup" ){
			 Debug.Log("Works");
		 }

		
		 
     }
}
