﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(PlayerController))]
public class GrabAndThrow : MonoBehaviour
{


    public GameObject grabBox;
    public Vector3 holdOffset;
    public Vector3 throwForce = new Vector3(0, 5, 7);
    public float rotateToBlockSpeed = 3;
    public float checkRadius = 0.5f;
    public float weightChange = 0.3f;
    public float holdingBreakForce = 45, holdingBreakTorque = 45;

    [HideInInspector]
    public GameObject heldObj;
    private Vector3 holdPos;
    private FixedJoint joint;
    private Color gizmoColor;
    private float timeOfPickup, timeOfThrow, defRotateSpeed;

    private PlayerController playerController;
    private TriggerParent triggerParent;
    private RigidbodyInterpolation objectDefInterpolation;

    private void Awake()
    {

        

        if (!grabBox)
        {
            grabBox = new GameObject();
            grabBox.AddComponent<BoxCollider>();
            grabBox.GetComponent<Collider>().isTrigger = true;
            grabBox.transform.parent = transform;
            grabBox.transform.localPosition = new Vector3(0f, 0f, 0.5f);
            grabBox.layer = 2;
            Debug.LogWarning("No grabBox assigned to 'GrabAndThrow' Script");

        }

        playerController = GetComponent<PlayerController>();
        defRotateSpeed = playerController.rotateSpeed;

    }

    private void Update()
    {
        // si ya se ha recogido un objeto, tirarlo al oprimir el boton "grab"
        if (Input.GetButtonDown("Grab") && heldObj && Time.time > timeOfPickup + 0.1f)
        {

            if (heldObj.tag == "Pickup")
            {
                ThrowPickup();
            }
        }

        if (heldObj && heldObj.tag == "Pushable"){

            if (Input.GetButtonUp("Grab"))
            {

                DropPushable();
            }

            if (!joint)
            {
                DropPushable();
                Debug.Log("'Pushable' object dropped because the 'holdingBreakForce' or 'holdingBreakTorque' was exceeded");
            }

        }

        
    }

    //recoger/ empujar
    private void OnTriggerStay(Collider other)
    {
        if (Input.GetButton("Grab"))
        {

            if (other.tag == "Pickup" && heldObj == null && timeOfThrow + 0.2f < Time.time)
            {
                LiftPickup(other);
            }

            if (other.tag == "Pushable" && heldObj == null && timeOfThrow + 0.2f < Time.time)
            {

                GrabPushable(other);
            }

        }
    }

    // para levantar (recoger) el objeto
    private void LiftPickup(Collider other){
    

        // posicion a donde vamos a llevar el objeto una vez se recoja
        Mesh otherMesh = other.GetComponent<MeshFilter>().mesh;
        holdPos = transform.position + transform.forward * holdOffset.z + transform.right * holdOffset.x + transform.up * holdOffset.y;
        holdPos.y += (GetComponent<Collider>().bounds.extents.y) + (otherMesh.bounds.extents.y);

        // si hay espacio encima del player, recoger objeto
        if (!Physics.CheckSphere(holdPos,checkRadius)){

            gizmoColor = Color.green;
            heldObj = other.gameObject;
            objectDefInterpolation = heldObj.GetComponent<Rigidbody>().interpolation;
            heldObj.GetComponent<Rigidbody>().interpolation = RigidbodyInterpolation.Interpolate;
            heldObj.transform.position = holdPos;
            heldObj.transform.rotation = transform.rotation;
            AddJoint();

            // le damos un cambio en el peso al objeto alterando la masa del mismo cuando lo recojemos¡
            heldObj.GetComponent<Rigidbody>().mass *= weightChange;

            // nos aseguramos de no tirar el objeto cuando lo recogemos
            timeOfPickup = Time.time;
        }else{

            gizmoColor = Color.red;

        }
    }

    // para tirar el objeto, solo si ya se ha recogido
    private void ThrowPickup(){

        Destroy(joint);

        Rigidbody rb = heldObj.GetComponent<Rigidbody>();
        rb.interpolation = objectDefInterpolation;
        rb.mass /= weightChange;
        rb.AddRelativeForce(throwForce, ForceMode.VelocityChange);

        heldObj = null;
        timeOfThrow = Time.time;

    }

    // para empujar/alar el objeto
    private void GrabPushable(Collider other){

        heldObj = other.gameObject;
        objectDefInterpolation = heldObj.GetComponent<Rigidbody>().interpolation;
        heldObj.GetComponent<Rigidbody>().interpolation = RigidbodyInterpolation.Interpolate;
        AddJoint();

        // nada de braeakForces para los que se puedan empujar/halar 
        joint.breakForce = Mathf.Infinity;
        joint.breakTorque = Mathf.Infinity;
        // detenemos la rotacion con respecto al movimiento para que el player pueda empujar o halar 
        playerController.rotateSpeed = 0;

    }

    private void DropPushable(){

        heldObj.GetComponent<Rigidbody>().interpolation = objectDefInterpolation;
        Destroy(joint);
        playerController.rotateSpeed = defRotateSpeed;
        heldObj = null;
        timeOfThrow = Time.time;
    }

    // para conectar el objeto que se recoje/empuja via Physics Joint
    private void AddJoint(){

        if (heldObj){
            joint = heldObj.AddComponent<FixedJoint>();
            joint.connectedBody = GetComponent<Rigidbody>();
        }

    }


    void OnDrawGizmosSelected()
    {
        Gizmos.color = gizmoColor;
        Gizmos.DrawSphere(holdPos, checkRadius);
    }




} // End Class
