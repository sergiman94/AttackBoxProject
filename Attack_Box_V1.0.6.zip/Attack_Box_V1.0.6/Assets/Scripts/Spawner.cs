﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {

	[SerializeField]
	private GameObject[] boxObjects;

	// Use this for initialization
	void Start () {
		SpawnRandom();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	public void SpawnRandom(){

		// int random = Random.Range(0, 2);
		// Vector3 rPos = new Vector3 (transform.position.x + random, transform.position.y, transform.position.z);

		int index = Random.Range(0, boxObjects.Length);
		Instantiate(boxObjects[index],transform.position, Quaternion.identity);
		
	}
}
