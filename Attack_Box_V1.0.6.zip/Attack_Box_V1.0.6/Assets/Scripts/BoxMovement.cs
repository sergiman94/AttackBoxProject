﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class BoxMovement : MonoBehaviour
{   

    private JoinObject joinObject; // Clase que ejecuta el joint 
    private Rigidbody rb;

    private BoxCollider bc;
    private MagnetAttraction magnetAttraction;

    


    void Start()
    {
        rb = GetComponent<Rigidbody>();
        joinObject = GetComponent<JoinObject>();
        bc = GetComponent<BoxCollider>();
        magnetAttraction = GetComponent<MagnetAttraction>();

        
        
    }

    void Update()
    {
        


        // Si no se presiona el boton para mover
        if (!Input.GetButton("Grab"))
        {

            //rb.constraints = RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
            // masa de la caja infinita, estatica 
            rb.mass = Mathf.Infinity;

            

            this.gameObject.tag = "Checks";

        }
        else //si no (si se oprime "Grab"), masa = 2 y poca friccion para mover el objeto
        {
            rb.constraints = RigidbodyConstraints.FreezeRotationZ;
            rb.mass = 2;
            bc.material.dynamicFriction = 0.6f;
            bc.material.staticFriction = 0.6f;

            

            //this.gameObject.tag = "Pickup";
            StartCoroutine(WaitTag(1));
        }

    }
    
    // Cuando entre al trigger(una caja toque a la otra por los lados), agregue el joint
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Pickup" && joinObject.otherObject == null)
        {
            joinObject.joinObject(other);
    
        }

    }

    IEnumerator WaitTag(float time){

        this.gameObject.tag = "Pickup";

        yield return new WaitForSeconds(time);

        this.gameObject.tag = "Checks";
    }

}
