﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrabAndPush : MonoBehaviour
{

    
    public float holdingBreakForce = 45;
    public float holdingBreakTorque = 45;

    [HideInInspector]
    public GameObject heldObject;
    private float defRotateSpeed, timeOfThrow;
    private Vector3 holdPos;
    private FixedJoint joint;
    private PlayerController playerController;
    private RigidbodyInterpolation objectDefInterpolation;

    private Rigidbody rb;

    void Awake()
    {

        playerController = GetComponent<PlayerController>();
        defRotateSpeed = playerController.rotateSpeed;

        rb = GetComponent<Rigidbody>();

    }

    void Update()
    {

        if (heldObject && heldObject.tag == "Pickup")
        {

            if (Input.GetButtonUp("Grab"))
            {
                DropObject();
            }

            if (!joint)
            {
                DropObject();
            }
        }

    }

    void FixedUpdate(){

        if (!Input.GetButton("Grab")){
            rb.isKinematic = false;
        }else{
            rb.isKinematic = true;
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (Input.GetButton("Grab")) 
        {   
            
            if (other.tag == "Pickup")
            {
                Push(other);
                
            }

            // if (other.tag == "Pickup" && heldObject == null && timeOfThrow < Time.time)
            // {

            //     GrabObject(other);

            // }

        }


    }

    private void GrabObject(Collider other)
    {

        heldObject = other.gameObject;
        objectDefInterpolation = heldObject.GetComponent<Rigidbody>().interpolation;
        heldObject.GetComponent<Rigidbody>().interpolation = RigidbodyInterpolation.Interpolate;
        AddJoint();

        joint.breakForce = Mathf.Infinity;
        joint.breakTorque = Mathf.Infinity;

        playerController.rotateSpeed = 0;

    }

    private void DropObject()
    {

        heldObject.GetComponent<Rigidbody>().interpolation = objectDefInterpolation;
        Destroy(joint);
        playerController.rotateSpeed = defRotateSpeed;
        heldObject = null;
        timeOfThrow = Time.time;

    }

    private void AddJoint()
    {

        if (heldObject)
        {
            joint = heldObject.AddComponent<FixedJoint>();
            joint.connectedBody = GetComponent<Rigidbody>();
        }

    }


    private void Push(Collider other)
    {
        Rigidbody rbOther = other.GetComponent<Rigidbody>();
        rbOther.AddForce(transform.forward * 100);
    }

}
