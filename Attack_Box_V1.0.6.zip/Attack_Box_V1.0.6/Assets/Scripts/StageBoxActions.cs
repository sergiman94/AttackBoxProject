﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageBoxActions : MonoBehaviour {

	public float magnetStrength = 5f;
	public float distanceStretch = 10f;
	public int magnetDirection = 1;
	public bool looseMagnet = true;
	public Vector3 magnetDir;

	private Transform trans;
	private Rigidbody thisRd;
	private Transform magnetTrans;
	private bool magnetInZone;

	void Awake(){
		trans = transform;
		thisRd = trans.GetComponent<Rigidbody>();
	}

	void FixedUpdate(){
		if(magnetInZone){

			Vector3 directionToMagnet = magnetTrans.position - trans.position;
			float distance = Vector3.Distance(magnetTrans.position, trans.position);
			float magnetDistanceStr = (distanceStretch/ distance ) * magnetStrength;

			thisRd.AddForce(magnetDistanceStr * (directionToMagnet * magnetDirection), ForceMode.Force);

		}
	}

	void OnTriggerEnter(Collider other){
		
		if(other.tag == "Magnet"){
			magnetTrans = other.transform;
			magnetInZone = true;
			//other.GetComponent<MagnetActions>().enabled = false;
		}

		if(other.tag == "Magnet"){
	 		other.GetComponent<MagnetActions>().newPosition = magnetDir;
	 	}

	}

	void OnCollisionStay(Collision collision){
		if(magnetInZone){
			trans = collision.gameObject.transform;
		}
	}

	void OnTriggerExit(Collider other){

		if(other.tag == "Magnet" && looseMagnet){
			magnetInZone = false;
		}

	}

}
