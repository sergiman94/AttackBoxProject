﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Positions : MonoBehaviour {

	public float[] arregloDePositions;

	// Use this for initialization
	void Start () {
		
		arregloDePositions = new float[12];

		 
		arregloDePositions[0] = -9.96f;
		arregloDePositions[1] =-7.98f;
		arregloDePositions[2] = -5.96f;
		arregloDePositions[3] = -3.93f;
		arregloDePositions[4] = -1.98f;
		arregloDePositions[5] = 0.04100001f;
		arregloDePositions[6] = 2.06f;
		arregloDePositions[7] = 4.08f;
		arregloDePositions[8] = 6.08f;
		arregloDePositions[9] = 8.099f;
		arregloDePositions[10] = 10.119f;
		arregloDePositions[11] = 12.1f;

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
