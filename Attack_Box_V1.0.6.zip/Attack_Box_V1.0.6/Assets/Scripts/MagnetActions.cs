﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagnetActions : MonoBehaviour {

	public Vector3 newPosition;

	[HideInInspector]
	public Transform trans;

	void Awake(){
		trans = transform;
	}

	void Update(){
		
		// interpolacion lineal --> Lerp
		trans.position = Vector3.Lerp(trans.position, newPosition, Time.deltaTime * 1.5f);

		if(Mathf.Abs(newPosition.x - trans.position.x ) < 0.05){
			trans.position = newPosition;
		}
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == "Magnet"){
			transform.position = new Vector3(11.0f, 1.3f, -1.13f);
		}
	}

	
	
}
