﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeDir : MonoBehaviour {

	//public Vector3 magnetDirection;
	private GameObject otherObject;
	private ScoreManager scoreManager;

	public Text CountText;
    public Text winText;

    public int count;

	

	void Start(){
		

		 count = 0;
        SetCountText();
        winText.text = "";
	}

	void update(){


	}
	
	void OnTriggerEnter(Collider other){

		otherObject = other.gameObject;
		
		count = count + 4;
            
        SetCountText();

		// Debug.Log("in");

	}

	void SetCountText(){

        CountText.text = count.ToString();

        //  if(count >= 20)
        //     winText.text = "You Win !";
    }

	
}
