﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{


    // Setup
    [HideInInspector]
    public Transform mainCam, floorChecks;
    private CharacterMotor characterMotor;
    private Rigidbody rb;
    private Transform[] floorCheckers;

    //Movement
    public float accel = 70f;
    public float airAccel = 18f;
    public float decel = 7.6f;
    public float airDecel = 1.1f;
    public float maxSpeed = 9;
    public float slopeLimit = 40;
    public float rotateSpeed = 0.7f, airRotateSpeed = 0.4f;
    public float jumpDelay = 0.1f;
    public float jumpForceImpulse = 5f;
    public bool grounded;
    private int onJump;
    private Vector3 jumpForce = new Vector3(0, 13, 0);
    private Vector3 direction, moveDirection, movObjSpeed;
    private float slope, groundedCount, airPressTime, curAccel, curDecel, curRotateSpeed;

    private void Awake()
    {
        if (!floorChecks)
        {

            floorChecks = new GameObject().transform;
            floorChecks.name = "FloorChecks";
            floorChecks.parent = transform;
            floorChecks.position = transform.position;
            GameObject check = new GameObject();
            check.name = "Check1";
            check.transform.parent = floorChecks;
            check.transform.position = transform.position;
            Debug.LogWarning("No 'floorChecks' assigned to PlayerMove script, so a single floorcheck has been created", floorChecks);
        }


        mainCam = GameObject.FindGameObjectWithTag("MainCamera").transform;
        characterMotor = GetComponent<CharacterMotor>();
        rb = GetComponent<Rigidbody>();

        //tomamos los child de los floorCheckers y los ponemos en un arreglo
        //para despues hacer un raycast hacia abajo con cada uno de ellos 
        floorCheckers = new Transform[floorChecks.childCount];
        for (int i = 0; i < floorCheckers.Length; i++)
        {

            floorCheckers[i] = floorChecks.GetChild(i);
        }

    }

    private void Update()
    {
        JumpCalculations();

        curAccel = (grounded) ? accel : airAccel;
        curDecel = (grounded) ? decel : airDecel;
        curRotateSpeed = (grounded) ? rotateSpeed : airRotateSpeed;

        float horizontal = Input.GetAxisRaw("Horizontal");
        //float vertical = Input.GetAxisRaw("Vertical");

        direction = Vector3.right * horizontal;
        moveDirection = transform.position + direction;

    }

    private void FixedUpdate()
    {
        grounded = IsGrounded();

        characterMotor.MoveTo(moveDirection, curAccel, 0.7f, true);
        if (rotateSpeed != 0 && direction.magnitude != 0)
        {
            characterMotor.RotateToDirection(moveDirection, curRotateSpeed * 5, true);
        }
        characterMotor.ManageSpeed(curDecel, maxSpeed + movObjSpeed.magnitude, true);

    }

    public bool IsGrounded()
    {

        float dist = GetComponent<Collider>().bounds.extents.y;

        foreach (Transform check in floorCheckers)
        {

            RaycastHit hit;

            if (Physics.Raycast(check.position, Vector3.down, out hit, dist + 0.05f))
            {

                if (!hit.transform.GetComponent<Collider>().isTrigger)
                {

                    //Control de la pendiente
                    slope = Vector3.Angle(hit.normal, Vector3.up);

                    return true;
                }
            }
        }

        return false;
    }

    public void JumpCalculations()
    {

        // guardamos el tiempo que se esta en el piso
        groundedCount = (grounded) ? groundedCount += Time.deltaTime : 0f;

        //guardamos el tiempo cuando se presiona saltar en el aire
        if (Input.GetButtonDown("Jump") && !grounded)
        {
            airPressTime = Time.time;
        }

        // si estamos en el piso y estamos en el limite de la pendiente
        if (grounded && slope < slopeLimit)
        {

            //onJump = (groundedCount < jumpDelay) ? Mathf.Min(2, onJump + 1) : 1;

            if (Input.GetButtonDown("Jump"))
            {

                if (onJump == 0)
                {
                    Jump(jumpForce);
                }
                else if (onJump == 1)
                {
                    Jump(jumpForce);
                    onJump--;
                }

            }

        }

    }

    public void Jump(Vector3 jumpVelocity)
    {

        rb.velocity = new Vector3(rb.velocity.x, jumpForceImpulse, rb.velocity.z);
        rb.AddRelativeForce(jumpVelocity, ForceMode.Impulse);
        airPressTime = 0f;

    }

    public void MoveForwardOnly()
    {

        characterMotor.MoveTo(moveDirection, curAccel, 0.7f, true);
        if (rotateSpeed != 0 && direction.magnitude != 0)
        {
            characterMotor.RotateToDirection(moveDirection, curRotateSpeed * 5, true);
        }
        characterMotor.ManageSpeed(curDecel, maxSpeed + movObjSpeed.magnitude, true);

    }




}
