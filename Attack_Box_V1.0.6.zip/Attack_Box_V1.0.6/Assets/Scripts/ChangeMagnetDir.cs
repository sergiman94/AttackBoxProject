﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeMagnetDir : MonoBehaviour {

	public Vector3 magnetDirection;
	
	void OnTriggerEnter(Collider other){
		if(other.tag == "Magnet"){
			other.GetComponent<MagnetActions>().newPosition = transform.position;
		}
	}

	void OnCollisionStay(Collision collision){
		collision.collider.GetComponent<MagnetActions>().newPosition = transform.position;
	}
}
