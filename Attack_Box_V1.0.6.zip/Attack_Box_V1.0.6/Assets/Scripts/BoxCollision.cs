﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxCollision : MonoBehaviour {

    public Transform upCheck, downCheck, rightCheck, leftCheck;
    public bool right, left, up, down;
    public float waitTime = 0.001f; 
    private Rigidbody rb;

    private FixedJoint joint;


    void Awake()
    {

    }

    void Start () {

        rb = GetComponent<Rigidbody>();

	}
	
	
	void FixedUpdate () {

        down = IsDown();
        up = IsUp();
        left = IsLeft();
        right = IsRight(); 
        
        if(!Input.GetButton("Grab")){

            rb.constraints = RigidbodyConstraints.FreezePositionX |RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
            
        }else{
            rb.constraints = RigidbodyConstraints.FreezeRotationZ;
        }
		
	}

    private void OnTriggerStay(Collider collider){

      

    }

    private void OnCollisionStay(Collision collision)
    {
       
        // if(!Input.GetButton("Grab")){
        //     if(collision.gameObject.tag == "Ground"){
        //         Freeze(true);
        //     }
        // }else{
        //     Freeze(false);
        // }
        
        // if(Input.GetButton("Grab") ){
        //     rb.constraints = RigidbodyConstraints.FreezeRotationZ;
               
        // }else{
        //     rb.constraints = RigidbodyConstraints.FreezePositionX;
        //     rb.constraints = RigidbodyConstraints.FreezePositionZ;
        // }
    }

    public bool IsDown(){

        float downDist = GetComponent<Collider>().bounds.extents.y;

        RaycastHit downHit;
        Vector3 downDir = downCheck.TransformDirection(Vector3.down * downDist);

        Ray downRay = new Ray(downCheck.position, downDir);

        Debug.DrawRay(downCheck.position, downDir, Color.blue);

        if (Physics.Raycast(downRay , out downHit, downDist )){

            return true;

        }else{

            return false;
        }

    }

    public bool IsUp(){

        float upDist = GetComponent<Collider>().bounds.extents.y + 0.05f;

        RaycastHit upHit;
        Vector3 upDir = upCheck.TransformDirection(Vector3.up * upDist);

        Ray upRay = new Ray(upCheck.position, upDir);

        Debug.DrawRay(upCheck.position, upDir, Color.green);

        if (Physics.Raycast(upRay, out upHit, upDist))
        {

            return true;

        }else{

            return false;
        }

    }

    public bool IsLeft(){

        float leftDist = GetComponent<Collider>().bounds.extents.x + 0.5f;

        RaycastHit leftHit;
        Vector3 leftDir = leftCheck.TransformDirection(Vector3.left * leftDist);

        Ray leftray = new Ray(leftCheck.position, leftDir);

        Debug.DrawRay(leftCheck.position, leftDir, Color.yellow);


        if (Physics.Raycast(leftray, out leftHit, leftDist ))
        {
            Addjoint(leftHit);
            return true;

        } else{

            return false;
        }



    }

    public bool IsRight(){

        float rightDist = GetComponent<Collider>().bounds.extents.x + 0.5f;

        RaycastHit rightHit;
        Vector3 rightDir = rightCheck.TransformDirection(Vector3.right * rightDist);

        Ray rightRay = new Ray(rightCheck.position, rightDir);

        Debug.DrawRay(rightCheck.position, rightDir, Color.magenta);

        if (Physics.Raycast(rightRay, out rightHit, rightDist))
        {
            return true;
        }else{

            return false;
        }

    }

    void Addjoint(RaycastHit hit){

        joint = hit.collider.gameObject.AddComponent<FixedJoint>();
        joint.connectedBody = GetComponent<Rigidbody>();

        
    }


}
