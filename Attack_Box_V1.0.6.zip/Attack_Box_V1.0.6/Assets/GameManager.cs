﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {
	
	public Player player;
	public DeathMenu deathMenu;

	public StatusIndicator statusIndicator;
	
	private Vector3 playerStartPoint;


	// Use this for initialization
	void Start () {
		playerStartPoint = player.transform.position;
		
	}
	
	// Update is called once per frame
	void Update () {
		
		

	}

	public void RestartGame(){
		//player.gameObject.SetActive(false);
		//deathMenu.gameObject.SetActive(true);

		Debug.Log("Restart Menu: On");

		Time.timeScale = 0;

		
	}

	public void Reset(){
		
		

		deathMenu.gameObject.SetActive(false);
		player.gameObject.SetActive(true);

		Player.PlayerStats.curHealth = Player.PlayerStats.maxHealth;

      	statusIndicator.SetHealth(Player.PlayerStats.curHealth, Player.PlayerStats.maxHealth);
		
		player.transform.position = playerStartPoint;

		//changeDir.count = 0;
		
		Debug.Log("Restart Menu: Off");
		Time.timeScale = 1;
		

	}

	public void KillPlayer(Player player){

        //Destroy(player.gameObject);

        player.gameObject.SetActive(false);

    
    }
}
